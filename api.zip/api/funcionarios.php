<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

include('db.php');

$metodo = $_SERVER['REQUEST_METHOD'];

if ($metodo == "GET") {
    $sql = "SELECT * FROM funcionarios";
    $result = $conn->query($sql);
    $funcionarios = [];
    while ($row = $result->fetch_assoc()) {
        $funcionarios[] = $row;
    }
    echo json_encode($funcionarios);
} else if ($metodo == "DELETE") {
    $id = $_GET['id'];
    $sql = "DELETE FROM funcionarios WHERE id = $id";
    if($conn->query($sql)) {
            echo json_encode([
        'status' => 'success',
        'mensagem' => 'Funcionario deletado com sucesso'
    ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'mensagem' => 'Erro ao deletar funcionario'
        ]);
    }
} else if ($metodo == "POST") {
    $data = json_decode(file_get_contents('php://input'), true);
    $nome = $data['nome'];
    $cargo = $data['cargo'];
    $salario = $data['salario'];
    $data_admissao = $data['dataAdmissao'];

    $sql = "INSERT INTO funcionarios (nome, cargo, salario, data_admissao) 
            VALUES ('$nome', '$cargo', '$salario', '$data_admissao')";

    if($conn->query($sql)) {
        $id = $conn->insert_id; // pega o ID do último inserido
        echo json_encode([
            'status' => 'success',
            'mensagem' => 'Funcionario criado com sucesso',
            'funcionario' => [
                'id' => $id,
                'nome' => $nome,
                'cargo' => $cargo,
                'salario' => $salario,
                'data_admissao' => $data_admissao
            ]
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'mensagem' => 'Erro ao criar funcionario'
        ]);
    }
}

$conn->close();
?>